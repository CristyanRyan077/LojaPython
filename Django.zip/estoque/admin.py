from django.contrib import admin
from .models import Cliente, produto


# Register your models here.

admin.site.register(Cliente)
admin.site.register(produto)
